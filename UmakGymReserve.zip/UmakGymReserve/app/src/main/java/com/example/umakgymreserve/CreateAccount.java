package com.example.umakgymreserve;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.HashMap;


public class CreateAccount extends AppCompatActivity {
    Button confirmAcc;
    EditText createUser, createPass;
    private final HashMap<String, String> userDatabase = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_account);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        confirmAcc = findViewById(R.id.btnConfirmAcc);
        createUser = findViewById(R.id.etCreateUsername);
        createPass = findViewById(R.id.etCreatePassword);

        confirmAcc.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#cfcf8c")));

        accountCreateConfirmation();
    }

    public void accountCreateConfirmation(){
        confirmAcc.setOnClickListener(v -> {
            String username = createUser.getText().toString().trim();
            String password = createPass.getText().toString().trim();

            if (userDatabase.containsKey(username)) {
                Toast.makeText(CreateAccount.this, "Username already taken", Toast.LENGTH_SHORT).show();
            } else {
                // Register the new user
                userDatabase.put(username, password);
                Toast.makeText(CreateAccount.this, "Registration Successful", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(this, LogReg.class);
                startActivity(intent);
                finish();
            }
        });
    }
}