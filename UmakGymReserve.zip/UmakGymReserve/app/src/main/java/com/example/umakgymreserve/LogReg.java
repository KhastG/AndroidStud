package com.example.umakgymreserve;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LogReg extends AppCompatActivity {
    Button login, signUp;

    EditText user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_log_reg);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        login = findViewById(R.id.btnLogin);
        signUp = findViewById(R.id.btnsignUp);

        user = findViewById(R.id.etUsername);
        pass = findViewById(R.id.etPassword);

        login.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#cfcf8c")));
        signUp.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#cfcf8c")));

        login.setOnClickListener(v ->{
            String username = user.getText().toString().trim();
            String password = user.getText().toString().trim();

            if(username.isEmpty()){
                user.setError("The username is empty!");
            } else{
                if(password.isEmpty()){
                    pass.setError("The password is empty!");
                } else{
                    Intent intent = new Intent(this, ReservationPage.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        signUp.setOnClickListener(v -> {
            Intent intent = new Intent(this, SignUp.class);
            startActivity(intent);
            finish();
        });
    }
}